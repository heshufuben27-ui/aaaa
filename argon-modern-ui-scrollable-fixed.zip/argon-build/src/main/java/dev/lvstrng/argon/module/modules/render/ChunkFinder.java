package dev.lvstrng.argon.module.modules.render;

import dev.lvstrng.argon.event.events.GameRenderListener;
import dev.lvstrng.argon.event.events.HudListener;

import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.utils.EncryptedString;
import dev.lvstrng.argon.utils.RenderUtils;
import dev.lvstrng.argon.utils.ProjectionUtils;
import dev.lvstrng.argon.utils.WorldUtils;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.block.entity.FurnaceBlockEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.world.Heightmap;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Heuristic base-candidate overlay. Scores are indicators, not statistically calibrated probabilities. */
public final class ChunkFinder extends Module implements GameRenderListener, HudListener {
    private final NumberSetting threshold = new NumberSetting(EncryptedString.of("Min Score %"), 0, 100, 25, 5);
    private final NumberSetting radius = new NumberSetting(EncryptedString.of("Range (chunks)"), 2, 16, 8, 1);
    private final BooleanSetting labels = new BooleanSetting(EncryptedString.of("Chunk Labels"), true);
    private final List<Candidate> candidates = new ArrayList<>();
    private int refreshTicks;

    public ChunkFinder() {
        super(EncryptedString.of("Chunk Finder"), EncryptedString.of("Highlights loaded chunks with base-like storage patterns"), -1, Category.RENDER);
        addSettings(threshold, radius, labels);
    }

    @Override public void onEnable() {
        eventManager.add(GameRenderListener.class, this);
        eventManager.add(HudListener.class, this);
        refreshCandidates();
    }

    @Override public void onDisable() {
        eventManager.remove(GameRenderListener.class, this);
        eventManager.remove(HudListener.class, this);
        candidates.clear();
    }

    private void refreshCandidates() {
        candidates.clear();
        if (mc.world == null || mc.player == null) return;
        ChunkPos center = mc.player.getChunkPos();
        int rangeChunks = radius.getValueInt();
        for (WorldChunk chunk : WorldUtils.getLoadedChunks().toList()) {
            ChunkPos pos = chunk.getPos();
            if (Math.abs(pos.x - center.x) > rangeChunks || Math.abs(pos.z - center.z) > rangeChunks) continue;
            int containers = 0, shulkers = 0, furnaces = 0;
            for (var blockPos : chunk.getBlockEntityPositions()) {
                BlockEntity be = mc.world.getBlockEntity(blockPos);
                if (be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity) containers++;
                else if (be instanceof ShulkerBoxBlockEntity) shulkers++;
                else if (be instanceof FurnaceBlockEntity) furnaces++;
            }
            // Heuristic candidate score (not a calibrated probability).
            // Diminishing returns prevent one large storage room from dominating;
            // variety of storage and utility blocks raises the score modestly.
            int storage = Math.min(42, containers * 9) + Math.min(18, shulkers * 6);
            int utility = Math.min(20, furnaces * 3);
            int variety = 0;
            if (containers > 0 && furnaces > 0) variety += 8;
            if (containers > 0 && shulkers > 0) variety += 8;
            if (shulkers > 0 && furnaces > 0) variety += 4;
            int score = Math.min(95, storage + utility + variety);
            if (score >= threshold.getValueInt()) candidates.add(new Candidate(pos, score, containers, shulkers, furnaces));
        }
        candidates.sort(Comparator.comparingInt(Candidate::score).reversed());
    }

    @Override public void onGameRender(GameRenderEvent event) {
        if (mc.world == null || mc.player == null) return;
        if (++refreshTicks >= 20) { refreshTicks = 0; refreshCandidates(); }
        Camera camera = mc.gameRenderer.getCamera();
        if (camera == null) return;
        MatrixStack matrices = event.matrices;
        Vec3d cameraPos = camera.getCameraPos();
        matrices.push();
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(camera.getPitch()));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(camera.getYaw() + 180.0F));
        matrices.translate(-cameraPos.x, -cameraPos.y, -cameraPos.z);
        for (Candidate candidate : candidates) {
            int x1 = candidate.pos.getStartX(), z1 = candidate.pos.getStartZ();
            float intensity = candidate.score / 95.0f;
            Color color = new Color(255, (int)(210 * (1.0f - intensity)), 35, 55 + (int)(90 * intensity));
            // Anchor the highlight to terrain height, not the player's changing Y coordinate.
            int surfaceY = mc.world.getTopY(Heightmap.Type.WORLD_SURFACE, x1 + 8, z1 + 8);
            RenderUtils.renderFilledBox(matrices, x1, surfaceY - 0.02f, z1,
                    x1 + 16, surfaceY + 0.08f, z1 + 16, color);
        }
        matrices.pop();

    }

    @Override
    public void onRenderHud(HudEvent event) {
        if (!labels.getValue() || mc.world == null || mc.player == null) return;
        for (Candidate candidate : candidates) {
            int x = candidate.pos.getStartX(), z = candidate.pos.getStartZ();
            int surfaceY = mc.world.getTopY(Heightmap.Type.WORLD_SURFACE, x + 8, z + 8);
            Vec3d anchor = new Vec3d(x + 8.0, surfaceY + 2.0, z + 8.0);
            ProjectionUtils.ProjectedPoint point = ProjectionUtils.project(anchor);
            if (point == null) continue;
            String text = String.format("BASE SCORE: %d/100", candidate.score);
            int textX = Math.round(point.x() - mc.textRenderer.getWidth(text) / 2.0f);
            int textY = Math.round(point.y());
            event.context.drawText(mc.textRenderer, text, textX, textY, 0xFFFFFFFF, true);
            String evidence = String.format("C:%d  S:%d  F:%d", candidate.containers, candidate.shulkers, candidate.furnaces);
            int evidenceX = Math.round(point.x() - mc.textRenderer.getWidth(evidence) / 2.0f);
            event.context.drawText(mc.textRenderer, evidence, evidenceX, textY + 10, 0xFFFFD080, true);
        }
    }

    private record Candidate(ChunkPos pos, int score, int containers, int shulkers, int furnaces) {}
}
