package dev.lvstrng.argon.managers;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import dev.lvstrng.argon.Argon;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.setting.*;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.List;
import java.util.Objects;

/** Persists module toggles, keybinds, and setting values in the Fabric config directory. */
public final class ProfileManager {
	private static final System.Logger LOGGER = System.getLogger("Argon/ProfileManager");
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final int SAVE_CHECK_INTERVAL_TICKS = 20;
	private static final String LEGACY_FOLDER = "UJHfsGGjbPfVZ";
	private static final String LEGACY_FILE = "a.json";

	private final Path profilePath;
	private String lastSavedSnapshot;
	private int ticksSinceSaveCheck;

	public ProfileManager() {
		profilePath = FabricLoader.getInstance().getConfigDir().resolve("argon").resolve("profile.json");
	}

	public Path getProfilePath() {
		return profilePath;
	}

	/** Loads the saved profile, migrating the old temporary-file format when it is available. */
	public void loadProfile() {
		Path sourcePath = Files.isRegularFile(profilePath) ? profilePath : findLegacyProfile();
		if (sourcePath == null) {
			// No profile exists yet. The first autosave will create one with current defaults.
			lastSavedSnapshot = null;
			return;
		}

		try {
			JsonObject root = GSON.fromJson(Files.readString(sourcePath), JsonObject.class);
			if (root == null)
				throw new IllegalStateException("Profile file is empty or invalid");

			JsonObject savedModules = getObject(root, "modules");
			List<Module> modules = Argon.INSTANCE.getModuleManager().getModules();
			for (Module module : modules) {
				JsonObject moduleConfig = savedModules == null
						? getObject(root, String.valueOf(modules.indexOf(module)))
						: getObject(savedModules, module.getClass().getName());
				if (moduleConfig == null)
					continue;

				loadModule(module, moduleConfig);
			}

			lastSavedSnapshot = serializeProfile();
			if (!sourcePath.equals(profilePath))
				saveProfile();
		} catch (Exception exception) {
			// Preserve an unreadable profile until the user makes a change, instead of replacing it
			// with defaults immediately on the next autosave.
			lastSavedSnapshot = serializeProfile();
			LOGGER.log(System.Logger.Level.WARNING, "Could not load Argon profile from " + sourcePath, exception);
		}
	}

	/** Checks for setting changes once per second and writes only when the profile has changed. */
	public void tick() {
		if (++ticksSinceSaveCheck < SAVE_CHECK_INTERVAL_TICKS)
			return;
		ticksSinceSaveCheck = 0;

		String snapshot = serializeProfile();
		if (!Objects.equals(snapshot, lastSavedSnapshot))
			writeProfile(snapshot);
	}

	/** Immediately saves the current profile, for shutdown and explicit save call sites. */
	public void saveProfile() {
		writeProfile(serializeProfile());
	}

	private void writeProfile(String snapshot) {
		Path temporaryPath = profilePath.resolveSibling(profilePath.getFileName() + ".tmp");
		try {
			Files.createDirectories(profilePath.getParent());
			Files.writeString(temporaryPath, snapshot, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
			try {
				Files.move(temporaryPath, profilePath, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
			} catch (AtomicMoveNotSupportedException ignored) {
				Files.move(temporaryPath, profilePath, StandardCopyOption.REPLACE_EXISTING);
			}
			lastSavedSnapshot = snapshot;
		} catch (IOException exception) {
			LOGGER.log(System.Logger.Level.WARNING, "Could not save Argon profile to " + profilePath, exception);
		}
	}

	private String serializeProfile() {
		JsonObject root = new JsonObject();
		root.addProperty("version", 2);
		JsonObject savedModules = new JsonObject();

		for (Module module : Argon.INSTANCE.getModuleManager().getModules()) {
			JsonObject moduleConfig = new JsonObject();
			moduleConfig.addProperty("enabled", module.isEnabled());
			JsonObject savedSettings = new JsonObject();
			for (Setting<?> setting : module.getSettings()) {
				JsonElement value = serializeSetting(setting);
				if (value != null)
					savedSettings.add(setting.getName().toString(), value);
			}
			moduleConfig.add("settings", savedSettings);
			savedModules.add(module.getClass().getName(), moduleConfig);
		}

		root.add("modules", savedModules);
		return GSON.toJson(root);
	}

	private JsonElement serializeSetting(Setting<?> setting) {
		if (setting instanceof BooleanSetting booleanSetting)
			return new JsonPrimitive(booleanSetting.getValue());
		if (setting instanceof ModeSetting<?> modeSetting)
			return new JsonPrimitive(modeSetting.getModeIndex());
		if (setting instanceof NumberSetting numberSetting)
			return new JsonPrimitive(numberSetting.getValue());
		if (setting instanceof KeybindSetting keybindSetting)
			return new JsonPrimitive(keybindSetting.getKey());
		if (setting instanceof StringSetting stringSetting)
			return new JsonPrimitive(stringSetting.getValue());
		if (setting instanceof MinMaxSetting minMaxSetting) {
			JsonObject value = new JsonObject();
			value.addProperty("min", minMaxSetting.getMinValue());
			value.addProperty("max", minMaxSetting.getMaxValue());
			return value;
		}
		return null;
	}

	private void loadModule(Module module, JsonObject moduleConfig) {
		JsonObject savedSettings = getObject(moduleConfig, "settings");
		for (int settingIndex = 0; settingIndex < module.getSettings().size(); settingIndex++) {
			Setting<?> setting = module.getSettings().get(settingIndex);
			JsonElement value = savedSettings == null
					? moduleConfig.get(String.valueOf(settingIndex))
					: savedSettings.get(setting.getName().toString());
			if (value == null)
				continue;

			try {
				loadSetting(module, setting, value);
			} catch (RuntimeException exception) {
				LOGGER.log(System.Logger.Level.WARNING, "Could not restore setting " + module.getName() + ": " + setting.getName(), exception);
			}
		}

		JsonElement enabled = moduleConfig.get("enabled");
		if (isBoolean(enabled)) {
			boolean shouldBeEnabled = enabled.getAsBoolean();
			if (module.isEnabled() != shouldBeEnabled) {
				try {
					module.setEnabled(shouldBeEnabled);
				} catch (RuntimeException exception) {
					LOGGER.log(System.Logger.Level.WARNING, "Could not restore enabled state for " + module.getName(), exception);
				}
			}
		}
	}

	private void loadSetting(Module module, Setting<?> setting, JsonElement value) {
		if (setting instanceof BooleanSetting booleanSetting && isBoolean(value)) {
			booleanSetting.setValue(value.getAsBoolean());
		} else if (setting instanceof ModeSetting<?> modeSetting && isNumber(value)) {
			modeSetting.setModeIndex(value.getAsInt());
		} else if (setting instanceof NumberSetting numberSetting && isNumber(value)) {
			numberSetting.setValue(value.getAsDouble());
		} else if (setting instanceof KeybindSetting keybindSetting && isNumber(value)) {
			keybindSetting.setKey(value.getAsInt());
			if (keybindSetting.isModuleKey())
				module.setKey(value.getAsInt());
		} else if (setting instanceof StringSetting stringSetting && value.isJsonPrimitive()) {
			stringSetting.setValue(value.getAsString());
		} else if (setting instanceof MinMaxSetting minMaxSetting && value.isJsonObject()) {
			JsonObject range = value.getAsJsonObject();
			JsonElement min = range.has("min") ? range.get("min") : range.get("1");
			JsonElement max = range.has("max") ? range.get("max") : range.get("2");
			if (isNumber(min) && isNumber(max)) {
				minMaxSetting.setMinValue(min.getAsDouble());
				minMaxSetting.setMaxValue(max.getAsDouble());
			}
		}
	}

	private Path findLegacyProfile() {
		String temporaryDirectory = System.getProperty("java.io.tmpdir", ".");
		String homeDirectory = System.getProperty("user.home", ".");
		List<Path> candidates = List.of(
				Path.of(temporaryDirectory, LEGACY_FOLDER, LEGACY_FILE),
				Path.of(homeDirectory, LEGACY_FOLDER, LEGACY_FILE)
		);
		return candidates.stream().filter(Files::isRegularFile).findFirst().orElse(null);
	}

	private static JsonObject getObject(JsonObject parent, String name) {
		if (!parent.has(name) || !parent.get(name).isJsonObject())
			return null;
		return parent.getAsJsonObject(name);
	}

	private static boolean isBoolean(JsonElement value) {
		return value != null && value.isJsonPrimitive() && value.getAsJsonPrimitive().isBoolean();
	}

	private static boolean isNumber(JsonElement value) {
		return value != null && value.isJsonPrimitive() && value.getAsJsonPrimitive().isNumber();
	}
}
