package dev.lvstrng.argon.module.modules.misc;

import dev.lvstrng.argon.event.events.TickListener;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.KeybindSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.utils.EncryptedString;
import dev.lvstrng.argon.utils.InventoryUtils;
import dev.lvstrng.argon.utils.KeyUtils;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;

public final class Windopeal extends Module implements TickListener {
	private final KeybindSetting activateKey = new KeybindSetting(EncryptedString.of("Activate Key"), -1, false);
	private final NumberSetting delay = new NumberSetting(EncryptedString.of("Delay"), 0, 20, 0, 1)
			.setDescription(EncryptedString.of("Delay before throwing the ender pearl"));
	private final NumberSetting windChargeDelay = new NumberSetting(EncryptedString.of("Wind Charge Delay"), 0, 20, 2, 1)
			.setDescription(EncryptedString.of("Delay between throwing the ender pearl and the wind charge"));
	private final BooleanSetting switchBack = new BooleanSetting(EncryptedString.of("Switch Back"), true);
	private final NumberSetting switchDelay = new NumberSetting(EncryptedString.of("Switch Delay"), 0, 20, 0, 1)
			.setDescription(EncryptedString.of("Delay after the wind charge before restoring the original hotbar slot"));

	private Stage stage = Stage.IDLE;
	private boolean keyWasPressed;
	private int ticksRemaining;
	private int previousSlot = -1;

	public Windopeal() {
		super(EncryptedString.of("Windopeal"),
				EncryptedString.of("Throws an ender pearl followed by a wind charge when you press the activate key"),
				-1,
				Category.MISC);
		addSettings(activateKey, delay, windChargeDelay, switchBack, switchDelay);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		resetSequence();
		keyWasPressed = false;
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		if (previousSlot >= 0 && mc.player != null)
			InventoryUtils.setInvSlot(previousSlot);
		resetSequence();
		keyWasPressed = false;
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.player == null || mc.world == null || mc.interactionManager == null)
			return;

		int key = activateKey.getKey();
		boolean keyPressed = key != -1 && KeyUtils.isKeyPressed(key);
		boolean activatedThisTick = keyPressed && !keyWasPressed;
		keyWasPressed = keyPressed;

		if (mc.currentScreen != null)
			return;

		if (stage == Stage.IDLE) {
			if (activatedThisTick)
				beginSequence();
			return;
		}

		if (ticksRemaining > 0) {
			ticksRemaining--;
			return;
		}

		switch (stage) {
			case THROW_PEARL -> throwPearl();
			case THROW_WIND_CHARGE -> throwWindCharge();
			case SWITCH_BACK -> finishSequence(true);
			case IDLE -> { }
		}
	}

	private void beginSequence() {
		if (!InventoryUtils.hasItemInHotbar(item -> item == Items.ENDER_PEARL)
				|| !InventoryUtils.hasItemInHotbar(item -> item == Items.WIND_CHARGE))
			return;

		previousSlot = mc.player.getInventory().getSelectedSlot();
		if (!InventoryUtils.selectItemFromHotbar(Items.ENDER_PEARL)) {
			resetSequence();
			return;
		}

		stage = Stage.THROW_PEARL;
		ticksRemaining = delay.getValueInt();
	}

	private void throwPearl() {
		if (!useSelectedItem()) {
			finishSequence(true);
			return;
		}

		if (!InventoryUtils.selectItemFromHotbar(Items.WIND_CHARGE)) {
			finishSequence(true);
			return;
		}
		stage = Stage.THROW_WIND_CHARGE;
		ticksRemaining = windChargeDelay.getValueInt();
	}

	private void throwWindCharge() {
		if (!useSelectedItem()) {
			finishSequence(true);
			return;
		}

		if (switchBack.getValue()) {
			int delayTicks = switchDelay.getValueInt();
			if (delayTicks == 0) {
				finishSequence(true);
			} else {
				stage = Stage.SWITCH_BACK;
				ticksRemaining = delayTicks;
			}
		} else {
			finishSequence(false);
		}
	}

	private boolean useSelectedItem() {
		ActionResult result = mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
		if (result.isAccepted())
			mc.player.swingHand(Hand.MAIN_HAND);
		return result.isAccepted();
	}

	private void finishSequence(boolean restoreSlot) {
		if (restoreSlot && previousSlot >= 0 && mc.player != null)
			InventoryUtils.setInvSlot(previousSlot);
		resetSequence();
	}

	private void resetSequence() {
		stage = Stage.IDLE;
		ticksRemaining = 0;
		previousSlot = -1;
	}

	private enum Stage {
		IDLE,
		THROW_PEARL,
		THROW_WIND_CHARGE,
		SWITCH_BACK
	}
}
