package dev.lvstrng.argon.module.setting;

import java.util.Arrays;
import java.util.List;

public final class ModeSetting<T extends Enum<T>> extends Setting<ModeSetting<T>> {
	public int index;
	private final List<T> possibleValues;
	private final int originalValue;

	public ModeSetting(CharSequence name, T defaultValue, Class<T> type) {
		super(name);
		T[] values = type.getEnumConstants();
		this.possibleValues = Arrays.asList(values);
		this.index = this.possibleValues.indexOf(defaultValue);
		this.originalValue = this.index;
	}

	public T getMode() {
		// Profiles created by older builds can contain invalid mode indexes.
		// Recover to the default rather than crashing while rendering the Click GUI.
		if (index < 0 || index >= possibleValues.size())
			index = originalValue;
		return possibleValues.get(index);
	}

	public void setMode(T mode) {
		int newIndex = possibleValues.indexOf(mode);
		index = newIndex >= 0 ? newIndex : originalValue;
	}

	public void setModeIndex(int mode) {
		index = mode >= 0 && mode < possibleValues.size() ? mode : originalValue;
	}

	public int getModeIndex() {
		return index;
	}

	public int getOriginalValue() {
		return originalValue;
	}

	public void cycle() {
		if (index < possibleValues.size() - 1)
			index++;
		else index = 0;
	}

	public boolean isMode(T mode) {
		return index == possibleValues.indexOf(mode);
	}

}
