package dev.lvstrng.argon.gui;

import dev.lvstrng.argon.Argon;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.modules.client.ClickGUI;
import dev.lvstrng.argon.utils.ColorUtils;
import dev.lvstrng.argon.utils.RenderUtils;
import dev.lvstrng.argon.utils.TextRenderer;
import dev.lvstrng.argon.utils.Utils;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static dev.lvstrng.argon.Argon.mc;

public final class ClickGui extends Screen {
	public List<Window> windows = new ArrayList<>();
	public Color currentColor;
	private String searchQuery = "";
	private boolean searchFocused;
	private static final int SEARCH_WIDTH = 270;
	private static final int SEARCH_HEIGHT = 28;
	private static final int SEARCH_Y = 18;
	private static final StackWalker sw = StackWalker.getInstance(StackWalker.Option.RETAIN_CLASS_REFERENCE);
	private Category selectedCategory = Category.RENDER;
	private int panelX, panelY, panelW, panelH;

	public ClickGui() {
		super(Text.empty());

		for (Category category : Category.values()) {
			windows.add(new Window(0, 0, 620, 42, category, this));
		}
	}

	public boolean isDraggingAlready() {
		for(Window window : windows)
			if(window.dragging)
				return true;

		return false;
	}

	@Override
	protected void setInitialFocus() {
		if (client == null) {
			return;
		}
		super.setInitialFocus();
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		if (mc.currentScreen == this) {
			if (Argon.INSTANCE.previousScreen != null)
				Argon.INSTANCE.previousScreen.render(context, 0, 0, delta);

			if (currentColor == null)
				currentColor = new Color(0, 0, 0, 0);
			else currentColor = new Color(0, 0, 0, currentColor.getAlpha());

			if (currentColor.getAlpha() != (ClickGUI.background.getValue() ? 200 : 0))
				currentColor = ColorUtils.smoothAlphaTransition(0.05F, ClickGUI.background.getValue() ? 200 : 0, currentColor);

			if (mc.currentScreen instanceof ClickGui) {
				context.fill(0, 0, mc.getWindow().getWidth(), mc.getWindow().getHeight(), currentColor.getRGB());
				// Lightweight animated "shader-like" backdrop: drifting particles and soft aurora bands.
				renderAnimatedBackdrop(context);
			}

			RenderUtils.unscaledProjection(context);
			mouseX = Math.round(mouseX * (float) MinecraftClient.getInstance().getWindow().getScaleFactor());
			mouseY = Math.round(mouseY * (float) MinecraftClient.getInstance().getWindow().getScaleFactor());
			super.render(context, mouseX, mouseY, delta);

			// Modern panel shell; animated backdrop remains behind the UI.
			int sw = mc.getWindow().getWidth();
			int sh = mc.getWindow().getHeight();
			panelW = Math.min(1040, sw - 48);
			panelH = Math.min(650, sh - 48);
			panelX = (sw - panelW) / 2;
			panelY = (sh - panelH) / 2;
			RenderUtils.renderRoundedQuad(context, new Color(7, 15, 32, 246), panelX, panelY, panelX + panelW, panelY + panelH, 14, 14, 14, 14, 30);
			RenderUtils.renderRoundedQuad(context, new Color(14, 25, 48, 255), panelX + 8, panelY + 8, panelX + 174, panelY + panelH - 8, 10, 10, 10, 10, 30);
			TextRenderer.drawString("ARGON", context, panelX + 24, panelY + 22, new Color(235, 243, 255).getRGB());
			TextRenderer.drawString("MODULES", context, panelX + 20, panelY + 58, new Color(125, 145, 177).getRGB());
			int cy = panelY + 82;
			for (Category category : Category.values()) {
				boolean active = category == selectedCategory;
				int rowY = cy;
				if (active) RenderUtils.renderRoundedQuad(context, new Color(53, 83, 132, 230), panelX + 14, rowY - 5, panelX + 166, rowY + 22, 6, 6, 6, 6, 20);
				TextRenderer.drawString(category.name, context, panelX + 26, rowY + 2, active ? Color.WHITE.getRGB() : new Color(175, 190, 213).getRGB());
				cy += 36;
			}
			TextRenderer.drawString("Base Finding Modules", context, panelX + 198, panelY + 22, new Color(235, 242, 255).getRGB());
			TextRenderer.drawString("Select a module to configure", context, panelX + 198, panelY + 43, new Color(143, 160, 190).getRGB());
			// Keep the legacy module controls, but constrain them to the new panel's content area.
			int contentX = panelX + 188;
			int contentY = panelY + 76;
			int contentRight = panelX + panelW - 18;
			int contentBottom = panelY + panelH - 16;
			for (Window window : windows) {
				boolean active = windowCategory(window) == selectedCategory;
				if (active) {
					window.setX(contentX);
					window.setY(contentY);
					window.setWidth(contentRight - contentX);
					// The category header is fixed; only the module list below it scrolls.
					window.setViewportHeight(contentBottom - contentY - window.getHeight());
					window.render(context, mouseX, mouseY, delta);
				}
			}
			renderSearchField(context);
			if (!searchQuery.isBlank() && windows.stream().noneMatch(Window::isVisibleForSearch))
				TextRenderer.drawCenteredString("No modules found", context, mc.getWindow().getWidth() / 2, searchFieldY() + SEARCH_HEIGHT + 12, Color.WHITE.getRGB());

			RenderUtils.scaledProjection(context);
		}
	}

	/** Draw a lightweight animated shader-like backdrop using vanilla GUI fills. */
	private Category windowCategory(Window window) { return window.getCategory(); }

	private void renderAnimatedBackdrop(DrawContext context) {
		long now = System.currentTimeMillis();
		int width = mc.getWindow().getWidth();
		int height = mc.getWindow().getHeight();
		// Slowly drifting translucent aurora bands.
		for (int i = 0; i < 5; i++) {
			double phase = now / 1800.0 + i * 1.37;
			int bandWidth = width / 2;
			int x = (int) Math.floor((Math.sin(phase) * 0.5 + 0.5) * (width + bandWidth)) - bandWidth / 2;
			int y = (int) (height * (0.12 + i * 0.17));
			int alpha = 10 + (int) ((Math.sin(phase * 0.7) + 1.0) * 7);
			int color = (alpha << 24) | ((40 + i * 8) << 16) | ((95 + i * 12) << 8) | (190 + i * 10);
			context.fill(x, y, x + bandWidth, y + Math.max(24, height / 16), color);
		}
		// Small drifting particles; deterministic positions avoid allocations and flicker.
		for (int i = 0; i < 42; i++) {
			double phase = now / (2200.0 + (i % 7) * 310.0) + i * 2.399;
			int x = Math.floorMod((int) (i * 97 + Math.sin(phase) * width * 0.12), Math.max(1, width));
			int y = Math.floorMod((int) (i * 53 - now / (90 + i % 5 * 15)), Math.max(1, height));
			int alpha = 28 + (int) ((Math.sin(phase) + 1.0) * 24);
			int color = (alpha << 24) | 0x009BCFFF;
			int size = (i % 5 == 0) ? 3 : 2;
			context.fill(x, y, x + size, y + size, color);
		}
	}

	private void renderSearchField(DrawContext context) {
		int x = searchFieldX();
		Color background = new Color(12, 12, 12, 220);
		int y = searchFieldY();
		RenderUtils.renderRoundedQuad(context, background, x, y, x + SEARCH_WIDTH, y + SEARCH_HEIGHT, 5, 5, 5, 5, 20);
		context.fill(x + 8, y + SEARCH_HEIGHT - 2, x + SEARCH_WIDTH - 8, y + SEARCH_HEIGHT - 1,
				Utils.getMainColor(255, 0).getRGB());

		String display = searchQuery.isEmpty() ? "Search modules..." : searchQuery;
		int availableWidth = SEARCH_WIDTH - 24;
		while (!display.isEmpty() && TextRenderer.getWidth(display) > availableWidth)
			display = display.substring(1);

		if (searchFocused && !searchQuery.isEmpty() && System.currentTimeMillis() % 1000 < 500)
			display += "|";

		int color = searchQuery.isEmpty() ? new Color(170, 170, 170).getRGB() : Color.WHITE.getRGB();
		TextRenderer.drawString(display, context, x + 12, y + 8, color);
	}

	private int searchFieldX() {
		return panelX + panelW - SEARCH_WIDTH - 24;
	}

	private int searchFieldY() {
		return panelY + 18;
	}

	private boolean isSearchFieldHovered(double mouseX, double mouseY) {
		int x = searchFieldX();
		return mouseX >= x && mouseX <= x + SEARCH_WIDTH
				&& mouseY >= searchFieldY() && mouseY <= searchFieldY() + SEARCH_HEIGHT;
	}

	public String getSearchQuery() {
		return searchQuery;
	}

	public boolean matchesSearch(Module module) {
		String query = searchQuery.trim().toLowerCase(Locale.ROOT);
		return query.isEmpty() || module.getName().toString().toLowerCase(Locale.ROOT).contains(query);
	}

	@Override
	public boolean keyPressed(KeyInput keyInput) {
		int keyCode = keyInput.key();
		int scanCode = keyInput.scancode();
		int modifiers = keyInput.modifiers();
		if (searchFocused) {
			if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
				searchFocused = false;
				return true;
			}
			if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
				if (!searchQuery.isEmpty())
					searchQuery = searchQuery.substring(0, searchQuery.offsetByCodePoints(searchQuery.length(), -1));
				return true;
			}
			if ((modifiers & GLFW.GLFW_MOD_CONTROL) != 0 && keyCode == GLFW.GLFW_KEY_A) {
				searchQuery = "";
				return true;
			}
			if ((modifiers & GLFW.GLFW_MOD_CONTROL) != 0 && keyCode == GLFW.GLFW_KEY_V) {
				appendSearchText(mc.keyboard.getClipboard());
				return true;
			}
			return true;
		}

		for (Window window : windows)
			if (window.isVisibleForSearch())
				window.keyPressed(keyCode, scanCode, modifiers);

		return super.keyPressed(keyInput);
	}

	@Override
	public boolean charTyped(CharInput charInput) {
		if (!searchFocused || !charInput.isValidChar())
			return super.charTyped(charInput);

		appendSearchText(charInput.asString());
		return true;
	}

	private void appendSearchText(String value) {
		if (value == null || value.isEmpty())
			return;
		StringBuilder filtered = new StringBuilder();
		for (int offset = 0; offset < value.length();) {
			int codePoint = value.codePointAt(offset);
			if (!Character.isISOControl(codePoint))
				filtered.appendCodePoint(codePoint);
			offset += Character.charCount(codePoint);
		}
		if (searchQuery.codePointCount(0, searchQuery.length()) + filtered.codePointCount(0, filtered.length()) <= 64)
			searchQuery += filtered;
	}

	@Override
	public boolean mouseClicked(Click click, boolean doubled) {
		double mouseX = click.x();
		double mouseY = click.y();
		int button = click.button();

		mouseX *= MinecraftClient.getInstance().getWindow().getScaleFactor();
		mouseY *= MinecraftClient.getInstance().getWindow().getScaleFactor();
		if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT && isSearchFieldHovered(mouseX, mouseY)) {
			searchFocused = true;
			return true;
		}
		searchFocused = false;
		if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT && mouseX >= panelX + 12 && mouseX <= panelX + 170) {
			int row = (int) ((mouseY - (panelY + 77)) / 36);
			if (row >= 0 && row < Category.values().length) { selectedCategory = Category.values()[row]; return true; }
		}

		if (mouseX >= panelX + 188 && mouseX <= panelX + panelW - 18
				&& mouseY >= panelY + 76 + 42 && mouseY <= panelY + panelH - 16) {
			for (Window window : windows)
				if (window.isVisibleForSearch() && window.getCategory() == selectedCategory)
					window.mouseClicked(mouseX, mouseY, button);
		}

		return super.mouseClicked(click, doubled);
	}

	@Override
	public boolean mouseDragged(Click click, double deltaX, double deltaY) {
		double mouseX = click.x();
		double mouseY = click.y();
		int button = click.button();

		mouseX *= MinecraftClient.getInstance().getWindow().getScaleFactor();
		mouseY *= MinecraftClient.getInstance().getWindow().getScaleFactor();

		for (Window window : windows)
			if (window.isVisibleForSearch())
				window.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);

		return super.mouseDragged(click, deltaX, deltaY);
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
		MinecraftClient mc = MinecraftClient.getInstance();
		mouseX *= mc.getWindow().getScaleFactor();
		mouseY *= mc.getWindow().getScaleFactor();

		if (mouseX >= panelX + 188 && mouseX <= panelX + panelW - 18
				&& mouseY >= panelY + 76 + 42 && mouseY <= panelY + panelH - 16) {
			for (Window window : windows)
				if (window.isVisibleForSearch() && window.getCategory() == selectedCategory)
					window.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
		}

		return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	public void close() {
		Argon.INSTANCE.getModuleManager().getModule(ClickGUI.class).setEnabledStatus(false);
		onGuiClose();
	}

	public void onGuiClose() {
		mc.setScreenAndRender(Argon.INSTANCE.previousScreen);
		currentColor = null;

		for (Window window : windows)
			window.onGuiClose();

		if (Argon.INSTANCE.getProfileManager() != null)
			Argon.INSTANCE.getProfileManager().saveProfile();
	}

	@Override
	public boolean mouseReleased(Click click) {
		double mouseX = click.x();
		double mouseY = click.y();
		int button = click.button();

		mouseX *= MinecraftClient.getInstance().getWindow().getScaleFactor();
		mouseY *= MinecraftClient.getInstance().getWindow().getScaleFactor();

		for (Window window : windows)
			window.mouseReleased(mouseX, mouseY, button);

		return super.mouseReleased(click);
	}
}
