package dev.lvstrng.argon.gui.components;

import dev.lvstrng.argon.Argon;
import dev.lvstrng.argon.gui.Window;
import dev.lvstrng.argon.gui.components.settings.*;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.modules.client.ClickGUI;
import dev.lvstrng.argon.module.setting.*;
import dev.lvstrng.argon.utils.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

import static dev.lvstrng.argon.Argon.mc;

public final class ModuleButton {
	public List<RenderableSetting> settings = new ArrayList<>();
	public Window parent;
	public Module module;
	public int offset;
	public boolean extended;
	public int settingOffset;
	public Color currentColor;
	public Color defaultColor = Color.WHITE;
	public Color currentAlpha;
	public AnimationUtils animation = new AnimationUtils(0);

	public ModuleButton(Window parent, Module module, int offset) {
		this.parent = parent;
		this.module = module;
		this.offset = offset;
		this.extended = false;

		settingOffset = parent.getHeight();
		for (Setting<?> setting : module.getSettings()) {
			if (setting instanceof BooleanSetting booleanSetting)
				settings.add(new CheckBox(this, booleanSetting, settingOffset));
			else if (setting instanceof NumberSetting numberSetting)
				settings.add(new Slider(this, numberSetting, settingOffset));
			else if (setting instanceof ModeSetting<?> modeSetting)
				settings.add(new ModeBox(this, modeSetting, settingOffset));
			else if (setting instanceof KeybindSetting keybindSetting)
				settings.add(new KeybindBox(this, keybindSetting, settingOffset));
			else if (setting instanceof StringSetting stringSetting)
				settings.add(new StringBox(this, stringSetting, settingOffset));
			else if (setting instanceof MinMaxSetting minMaxSetting)
				settings.add(new MinMaxSlider(this, minMaxSetting, settingOffset));

			settingOffset += parent.getHeight();
		}
	}

	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		if (parent.getY() + offset > MinecraftClient.getInstance().getWindow().getHeight())
			return;

		for (RenderableSetting renderableSetting : settings)
			renderableSetting.onUpdate();

		if (currentColor == null)
			currentColor = new Color(0, 0, 0, 0);
		else currentColor = new Color(0, 0, 0, currentColor.getAlpha());

		int toAlpha = 170;

		currentColor = ColorUtils.smoothAlphaTransition(0.05F, toAlpha, currentColor);

		Color toColor = module.isEnabled() ? Utils.getMainColor(255, Argon.INSTANCE.getModuleManager().getModulesInCategory(module.getCategory()).indexOf(module)) : Color.WHITE;

		if (defaultColor != toColor)
			defaultColor = ColorUtils.smoothColorTransition(0.1F, toColor, defaultColor);

		// Modern card row: preserve the original module toggle and settings behavior.
		int rowTop = parent.getY() + offset + 2;
		int rowBottom = parent.getY() + offset + parent.getHeight() - 2;
		int rowLeft = parent.getX() + 5;
		int rowRight = parent.getX() + parent.getWidth() - 5;
		boolean hovered = isHovered(mouseX, mouseY);
		Color cardColor = module.isEnabled()
				? new Color(29, 48, 77, hovered ? 245 : 225)
				: new Color(18, 29, 49, hovered ? 240 : 205);
		RenderUtils.renderRoundedQuad(context, cardColor, rowLeft, rowTop, rowRight, rowBottom, 7, 7, 7, 7, 20);
		if (module.isEnabled()) {
			context.fill(rowLeft, rowTop + 5, rowLeft + 2, rowBottom - 5, Utils.getMainColor(255, Argon.INSTANCE.getModuleManager().getModulesInCategory(module.getCategory()).indexOf(module)).getRGB());
		}

		int textX = rowLeft + 13;
		int nameY = rowTop + 5;
		TextRenderer.drawString(module.getName(), context, textX, nameY,
				module.isEnabled() ? new Color(245, 248, 255).getRGB() : new Color(220, 228, 241).getRGB());

		// Secondary description gives each module the compact subtitle seen in the reference.
		String description = module.getDescription().toString();
		int maxDescriptionWidth = Math.max(30, rowRight - textX - 76);
		while (!description.isEmpty() && TextRenderer.getWidth(description) > maxDescriptionWidth)
			description = description.substring(0, description.length() - 1);
		if (!description.isEmpty())
			TextRenderer.drawString(description, context, textX, rowTop + 22, new Color(143, 160, 187).getRGB());

		// Right-side slide switch (visual state is always read from the real module state).
		int switchW = 32;
		int switchH = 16;
		int switchX = rowRight - switchW - 10;
		int switchY = rowTop + (parent.getHeight() - switchH) / 2 - 2;
		Color switchColor = module.isEnabled() ? new Color(85, 151, 239, 255) : new Color(51, 66, 91, 255);
		RenderUtils.renderRoundedQuad(context, switchColor, switchX, switchY, switchX + switchW, switchY + switchH, 8, 8, 8, 8, 20);
		int knobRadius = 5;
		int knobX = module.isEnabled() ? switchX + switchW - 8 : switchX + 8;
		RenderUtils.renderCircle(context, new Color(238, 244, 255), knobX, switchY + switchH / 2.0, knobRadius, 15);

		// Chevron hints that right-click opens the existing settings panel.
		int arrowX = switchX - 17;
		int arrowY = rowTop + parent.getHeight() / 2 - 2;
		context.fill(arrowX, arrowY, arrowX + 2, arrowY + 2, new Color(137, 157, 190).getRGB());
		context.fill(arrowX + 2, arrowY + 2, arrowX + 4, arrowY + 4, new Color(137, 157, 190).getRGB());
		context.fill(arrowX, arrowY + 4, arrowX + 2, arrowY + 6, new Color(137, 157, 190).getRGB());

		renderHover(context, mouseX, mouseY, delta);
		renderSettings(context, mouseX, mouseY, delta);

		for(RenderableSetting renderableSetting : settings)
			if(extended) renderableSetting.renderDescription(context, mouseX, mouseY, delta);

		if (isHovered(mouseX, mouseY) && !parent.dragging) {
			CharSequence chars = module.getDescription();

			int tw = TextRenderer.getWidth(chars);

			int parentCenter = mc.getWindow().getFramebufferWidth() / 2;
			int textCenter = parentCenter - tw / 2;

			RenderUtils.renderRoundedQuad(
					context,
					new Color(100, 100, 100, 100),
					textCenter - 5,
					((double) mc.getWindow().getFramebufferHeight() / 2) + 294,
					textCenter + tw + 5,
					((double) mc.getWindow().getFramebufferHeight() / 2) + 318,
					3,
					10
			);

			TextRenderer.drawString(chars, context, textCenter, (mc.getWindow().getFramebufferHeight() / 2) + 300, Color.WHITE.getRGB());
		}
	}

	private void renderHover(DrawContext context, int mouseX, int mouseY, float delta) {
		if (!parent.dragging) {
			int toHoverAlpha = isHovered(mouseX, mouseY) ? 15 : 0;

			if (currentAlpha == null)
				currentAlpha = new Color(255, 255, 255, toHoverAlpha);
			else currentAlpha = new Color(255, 255, 255, currentAlpha.getAlpha());

			if (currentAlpha.getAlpha() != toHoverAlpha)
				currentAlpha = ColorUtils.smoothAlphaTransition(0.05F, toHoverAlpha, currentAlpha);

			context.fill(parent.getX(), parent.getY() + offset, parent.getX() + parent.getWidth(), parent.getY() + parent.getHeight() + offset, currentAlpha.getRGB());
		}
	}

	private void renderSettings(DrawContext context, int mouseX, int mouseY, float delta) {
		int scissorX1 = parent.getX();
		int scissorY1 = parent.getY() + offset;
		int scissorX2 = scissorX1 + parent.getWidth();
		int scissorY2 = scissorY1 + (int) animation.getValue();

		context.enableScissor(scissorX1, scissorY1, scissorX2, scissorY2);

		for (RenderableSetting renderableSetting : settings)
			if(animation.getValue() > parent.getHeight())
				renderableSetting.render(context, mouseX, mouseY, delta);

		for (RenderableSetting renderableSetting : settings) {
			if(animation.getValue() > parent.getHeight()) {
				if (renderableSetting instanceof Slider slider) {
					RenderUtils.renderCircle(context, new Color(0, 0, 0, 170), (slider.parentX() + (Math.max(slider.lerpedOffsetX, 2.5))), slider.parentY() + slider.offset + slider.parentOffset() + 27.5, 6, 15);
					RenderUtils.renderCircle(context, slider.currentColor1.brighter(), (slider.parentX() + (Math.max(slider.lerpedOffsetX, 2.5))) , slider.parentY() + slider.offset + slider.parentOffset() + 27.5, 5, 15);

				} else if (renderableSetting instanceof MinMaxSlider slider) {
					RenderUtils.renderCircle(context, new Color(0, 0, 0, 170), (slider.parentX() + (Math.max(slider.lerpedOffsetMinX, 2.5))), slider.parentY() + slider.offset + slider.parentOffset() + 27.5, 6, 15);
					RenderUtils.renderCircle(context, slider.currentColor1.brighter(), (slider.parentX() + (Math.max(slider.lerpedOffsetMinX, 2.5))), slider.parentY() + slider.offset + slider.parentOffset() + 27.5, 5, 15);

					RenderUtils.renderCircle(context, new Color(0, 0, 0, 170), (slider.parentX() + (Math.max(slider.lerpedOffsetMaxX, 2.5))), slider.parentY() + slider.offset + slider.parentOffset() + 27.5, 6, 15);
					RenderUtils.renderCircle(context, slider.currentColor1.brighter(), (slider.parentX() + (Math.max(slider.lerpedOffsetMaxX, 2.5))), slider.parentY() + slider.offset + slider.parentOffset() + 27.5, 5, 15);
				}
			}
		}

		context.disableScissor();
	}

	public void onExtend() {
		for(ModuleButton moduleButton : parent.moduleButtons) {
			moduleButton.extended = false;
		}
	}

	public void keyPressed(int keyCode, int scanCode, int modifiers) {
		for (RenderableSetting setting : settings)
			setting.keyPressed(keyCode, scanCode, modifiers);
	}

	public void mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
		if (extended)
			for (RenderableSetting renderableSetting : settings)
				renderableSetting.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
	}

	public void mouseClicked(double mouseX, double mouseY, int button) {
		if (isHovered(mouseX, mouseY)) {
			if (button == 0)
				module.toggle();

			if (button == 1) {
				if (module.getSettings().isEmpty()) return;
				if (!extended)
					onExtend();

				extended = !extended;
			}
		}
		if (extended) {
			for (RenderableSetting renderableSetting : settings) {
				renderableSetting.mouseClicked(mouseX, mouseY, button);
			}
		}
	}

	public void onGuiClose() {
		this.currentAlpha = null;
		this.currentColor = null;

		for (RenderableSetting renderableSetting : settings)
			renderableSetting.onGuiClose();
	}

	public void mouseReleased(double mouseX, double mouseY, int button) {
		for (RenderableSetting renderableSetting : settings)
			renderableSetting.mouseReleased(mouseX, mouseY, button);
	}

	public boolean isHovered(double mouseX, double mouseY) {
		return mouseX > parent.getX()
				&& mouseX < parent.getX() + parent.getWidth()
				&& mouseY > parent.getY() + offset
				&& mouseY < parent.getY() + offset + parent.getHeight();
	}
}
