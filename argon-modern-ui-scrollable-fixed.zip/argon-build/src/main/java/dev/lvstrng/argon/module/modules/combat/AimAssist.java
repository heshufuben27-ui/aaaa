package dev.lvstrng.argon.module.modules.combat;

import dev.lvstrng.argon.Argon;
import dev.lvstrng.argon.event.events.HudListener;
import dev.lvstrng.argon.event.events.MouseMoveListener;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.modules.client.Friends;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.MinMaxSetting;
import dev.lvstrng.argon.module.setting.ModeSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.utils.*;
import dev.lvstrng.argon.utils.rotation.Rotation;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public final class AimAssist extends Module implements HudListener, MouseMoveListener {
	private final BooleanSetting stickyAim = new BooleanSetting(EncryptedString.of("Sticky Aim"), false)
			.setDescription(EncryptedString.of("Aims at the last attacked player"));

	private final BooleanSetting onlyWeapon = new BooleanSetting(EncryptedString.of("Only Weapon"), true);

	private final BooleanSetting onLeftClick = new BooleanSetting(EncryptedString.of("On Left Click"), false)
			.setDescription(EncryptedString.of("Only gets triggered if holding down left click"));
	private final ModeSetting<AimMode> aimAt = new ModeSetting<>(EncryptedString.of("Aim At"), AimMode.Chest, AimMode.class);

	private final BooleanSetting stopAtTargetVertical = new BooleanSetting(EncryptedString.of("Stop at Target Vert"), true)
			.setDescription(EncryptedString.of("Stops vertically assisting if already aiming at the entity, helps bypass anti-cheat"));

	private final BooleanSetting stopAtTargetHorizontal = new BooleanSetting(EncryptedString.of("Stop at Target Horiz"), false)
			.setDescription(EncryptedString.of("Stops horizontally assisting if already aiming at the entity, helps bypass anti-cheat"));

	private final NumberSetting radius = new NumberSetting(EncryptedString.of("Radius"), 0.1, 6, 5, 0.1);

	private final BooleanSetting seeOnly = new BooleanSetting(EncryptedString.of("See Only"), true);
	private final BooleanSetting lookAtNearest = new BooleanSetting(EncryptedString.of("Look at Nearest"), false);

	private final NumberSetting fov = new NumberSetting(EncryptedString.of("FOV"), 5, 360, 180, 1);

	private final MinMaxSetting pitchSpeed = new MinMaxSetting(EncryptedString.of("Vertical Speed"), 0, 10, 0.1, 2, 4);
	private final MinMaxSetting yawSpeed = new MinMaxSetting(EncryptedString.of("Horizontal Speed"), 0, 10, 0.1, 2, 4);

	private final NumberSetting speedChange = new NumberSetting(EncryptedString.of("Speed Delay"), 0, 1000, 250, 1)
			.setDescription(EncryptedString.of("Time in milliseconds to wait after resetting random speed"));

	private final NumberSetting randomization = new NumberSetting(EncryptedString.of("Chance"), 0, 100, 50, 1);

	private final BooleanSetting yawAssist = new BooleanSetting(EncryptedString.of("Horizontal"), true);
	private final BooleanSetting pitchAssist = new BooleanSetting(EncryptedString.of("Vertical"), true);

	private final NumberSetting waitFor = new NumberSetting(EncryptedString.of("Wait on Move"), 0, 1000, 0, 1)
			.setDescription(EncryptedString.of("After you move your mouse aim assist will stop working for the selected amount of time"));

	private final ModeSetting<LerpMode> lerp = new ModeSetting<>(EncryptedString.of("Lerp"), LerpMode.Normal, LerpMode.class)
			.setDescription(EncryptedString.of("Linear interpolation to use to rotate"));

	private final ModeSetting<PosMode> posMode = new ModeSetting<>(EncryptedString.of("Pos mode"), PosMode.Normal, PosMode.class)
			.setDescription(EncryptedString.of("Precision of the target position"));

	private final TimerUtils timer = new TimerUtils();
	private final TimerUtils resetSpeed = new TimerUtils();
	private boolean move;
	private float pitch, yaw;

	@SuppressWarnings("unused")
	public enum PosMode {
		Normal, Lerped
	}

	public enum AimMode {
		Head, Chest, Legs
	}

	public enum LerpMode {
		Normal, Smoothstep, EaseOut
	}

	public AimAssist() {
		super(EncryptedString.of("Aim Assist"),
				EncryptedString.of("Automatically aims at players for you"),
				-1,
				Category.COMBAT);

		addSettings(stickyAim, onlyWeapon, onLeftClick, aimAt, stopAtTargetVertical, stopAtTargetHorizontal, radius, seeOnly, lookAtNearest, fov, pitchSpeed, yawSpeed, speedChange, randomization, yawAssist, pitchAssist, waitFor, lerp, posMode);
	}

	@Override
	public void onEnable() {
		move = true;
		pitch = pitchSpeed.getRandomValueFloat();
		yaw = yawSpeed.getRandomValueFloat();

		eventManager.add(HudListener.class, this);
		eventManager.add(MouseMoveListener.class, this);

		timer.reset();
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(HudListener.class, this);
		eventManager.remove(MouseMoveListener.class, this);
		super.onDisable();
	}

	@Override
	public void onRenderHud(HudEvent event) {
		if (timer.delay(waitFor.getValueFloat()) && !move) {
			move = true;
			timer.reset();
		}

		if (mc.player == null || mc.world == null || mc.currentScreen != null)
			return;

		if (onlyWeapon.getValue() && !WorldUtils.isWeapon(mc.player.getMainHandStack()))
			return;

		if (onLeftClick.getValue() && GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) != GLFW.GLFW_PRESS)
			return;

		PlayerEntity target = findTarget();

		if (target == null)
			return;

		if(resetSpeed.delay(speedChange.getValueFloat())) {
			pitch = pitchSpeed.getRandomValueFloat();
			yaw = yawSpeed.getRandomValueFloat();
			resetSpeed.reset();
		}

		Rotation rotation = getTargetRotation(target);

		double angleToRotation = RotationUtils.getAngleToRotation(rotation);
		if (angleToRotation > (double) fov.getValueInt() / 2)
			return;

		float yawStrength = yaw / 50;
		float pitchStrength = pitch / 50;

		float yaw = mc.player.getYaw();
		float pitch = mc.player.getPitch();

		if (lerp.isMode(LerpMode.Smoothstep)) {
			yaw = (float) smoothStepLerp(yawStrength, mc.player.getYaw(), (float) rotation.yaw());
			pitch = (float) smoothStepLerp(pitchStrength, mc.player.getPitch(), (float) rotation.pitch());
		}

		if (lerp.isMode(LerpMode.Normal)) {
			yaw = lerp(yawStrength, mc.player.getYaw(), (float) (rotation.yaw()));
			pitch = lerp(pitchStrength, mc.player.getPitch(), (float) (rotation.pitch()));
		}

		if (lerp.isMode(LerpMode.EaseOut)) {
			yaw = (float) easeOutBackDegrees(mc.player.getYaw(), rotation.yaw(), yawStrength * RenderUtils.frameDelta());
			pitch = (float) easeOutBackDegrees(mc.player.getPitch(), rotation.pitch(), pitchStrength * RenderUtils.frameDelta());
		}

		if (MathUtils.randomInt(1, 100) <= randomization.getValueInt()) {
			if (move) {
				if (yawAssist.getValue()) {
					if(stopAtTargetHorizontal.getValue() && WorldUtils.getHitResult(radius.getValue()) instanceof EntityHitResult hitResult && hitResult.getEntity() == target)
						return;

					mc.player.setYaw(yaw);
				}

				if (pitchAssist.getValue()) {
					if(stopAtTargetVertical.getValue() && WorldUtils.getHitResult(radius.getValue()) instanceof EntityHitResult hitResult && hitResult.getEntity() == target)
						return;

					mc.player.setPitch(pitch);
				}
			}
		}
	}

	/**
	 * Selects the valid opponent closest to the current view direction, matching
	 * Meteor's ClosestAngle target priority instead of always choosing the nearest
	 * player by distance.
	 */
	private PlayerEntity findTarget() {
		double maxAngle = (double) fov.getValueInt() / 2;

		if (stickyAim.getValue() && mc.player.getAttacking() instanceof PlayerEntity attacked
				&& isValidTarget(attacked)
				&& RotationUtils.getAngleToRotation(getTargetRotation(attacked)) <= maxAngle) {
			return attacked;
		}

		PlayerEntity bestTarget = null;
		double bestAngle = Double.POSITIVE_INFINITY;
		double bestDistance = Double.POSITIVE_INFINITY;

		for (PlayerEntity candidate : mc.world.getPlayers()) {
			if (!isValidTarget(candidate))
				continue;

			Rotation candidateRotation = getTargetRotation(candidate);
			double angle = RotationUtils.getAngleToRotation(candidateRotation);
			if (angle > maxAngle)
				continue;

			double distance = candidate.distanceTo(mc.player);
			if (angle < bestAngle || (angle == bestAngle && distance < bestDistance)) {
				bestTarget = candidate;
				bestAngle = angle;
				bestDistance = distance;
			}
		}

		return bestTarget;
	}

	private boolean isValidTarget(PlayerEntity target) {
		if (target == null || target == mc.player || !target.isAlive() || target.isSpectator())
			return false;

		if (target.distanceTo(mc.player) > radius.getValueFloat())
			return false;

		if (seeOnly.getValue() && !mc.player.canSee(target))
			return false;

		Friends friends = Argon.INSTANCE.getModuleManager().getModule(Friends.class);
		return friends == null || !friends.disableAimAssist.getValue()
				|| !Argon.INSTANCE.getFriendManager().isFriend(target);
	}

	private Rotation getTargetRotation(PlayerEntity target) {
		Vec3d targetPos = posMode.isMode(PosMode.Normal)
				? target.getEntityPos()
				: target.getLerpedPos(RenderUtils.tickProgress());

		double targetHeight = target.getHeight();
		if (aimAt.isMode(AimMode.Head))
			targetPos = targetPos.add(0, targetHeight * 0.90, 0);
		else if (aimAt.isMode(AimMode.Chest))
			targetPos = targetPos.add(0, targetHeight * 0.50, 0);
		else if (aimAt.isMode(AimMode.Legs))
			targetPos = targetPos.add(0, targetHeight * 0.20, 0);

		Vec3d eyePos = mc.player.getCameraPosVec(RenderUtils.tickProgress());
		if (lookAtNearest.getValue()) {
			Vec3d towardPlayer = eyePos.subtract(targetPos);
			double horizontalDistance = Math.sqrt(towardPlayer.x * towardPlayer.x + towardPlayer.z * towardPlayer.z);
			if (horizontalDistance > 1.0E-6) {
				targetPos = targetPos.add(towardPlayer.x / horizontalDistance * 0.29, 0,
						towardPlayer.z / horizontalDistance * 0.29);
			}
		}

		// Meteor-style direction: calculate yaw/pitch from the camera eye to a point
		// inside the target's hitbox, then keep yaw on the shortest angular path.
		double dx = targetPos.x - eyePos.x;
		double dy = targetPos.y - eyePos.y;
		double dz = targetPos.z - eyePos.z;
		double horizontalDistance = Math.sqrt(dx * dx + dz * dz);
		double targetYaw = Math.toDegrees(Math.atan2(dz, dx)) - 90.0;
		double yaw = mc.player.getYaw() + MathHelper.wrapDegrees(targetYaw - mc.player.getYaw());
		double pitch = -Math.toDegrees(Math.atan2(dy, horizontalDistance));

		return new Rotation(yaw, Math.max(-90.0, Math.min(90.0, pitch)));
	}

	public float lerp(float delta, float start, float end) {
		return start + (MathHelper.wrapDegrees(end - start) * delta);
	}

	public static double easeOutBackDegrees(double start, double end, float speed) {
		double c1 = 1.70158;
		double c3 = 2.70158;
		double x = 1 - Math.pow(1 - (double) speed, 3);

		return start + MathHelper.wrapDegrees(end - start) * (1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2));
	}

	public double smoothStepLerp(double delta, double start, double end) {
		double value;
		delta = Math.max(0, Math.min(1, delta));

		double t = delta * delta * (3 - 2 * delta);

		value = start + MathHelper.wrapDegrees(end - start) * t;
		return value;
	}

	@Override
	public void onMouseMove(MouseMoveEvent event) {
		move = false;
		timer.reset();
	}
}
