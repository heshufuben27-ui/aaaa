# Remaining 1.21.11 migration work

The original code used the pre-1.21.6 immediate shader/state API. In the 1.21.11 mapped client, `RenderSystem.setShader`, `RenderSystem.setShaderColor`, old blend/depth toggles, and `GameRenderer.getPosition*Program` are not available in the same form. Remaining work is therefore not just import changes:

1. Move GUI primitives to `DrawContext`/GUI extraction APIs where possible.
2. Move world-space lines and boxes into the 1.21.11 render layer/pipeline path and preserve depth behavior for ESP.
3. Rework custom font glyph rendering to use registered textures and a compatible text pipeline, including underlines/strikethroughs.
4. Build with Java 21 + Gradle 9.2.0 in an environment that can resolve the Gradle distribution; fix all remaining compile errors, then test launch and render behavior.

No build success or in-game behavior is claimed for this work-in-progress source.
